Greenpois0n Absinthe 2.0.4 Windows Self-Extractor
-------------------------------------------------

Please extract the absinthe-win-2.0.4.exe to a reasonable location like
the Desktop or your My Documents folder, then double click it.
This will extract the whole Absinthe files into a new folder called
'absinthe-win-2.0.4'.
Open this folder and run absinthe.exe to run the actual Absinthe
jailbreak application.

Good luck!

